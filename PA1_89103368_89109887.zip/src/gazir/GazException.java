package gazir;

public class GazException extends Exception{

}
