package index;

public interface GazTokenProcessor {
	String processToken(String token);
}
